import './index.css'
import ProfilePageWithGraph from './components/ProfilePageWithGraph'

function App() {
  return <ProfilePageWithGraph />
}

export default App