import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { ChevronDown, ChevronRight, Clock, Bookmark } from 'lucide-react';

const ArticleSelection = ({ activeSection, setActiveSection }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [dynamicMenuItems, setDynamicMenuItems] = useState([]);
  
  // Combine static and dynamic items
  const staticItems = [
    { id: 'record1', name: '최근 본 기사', Icon: Clock },
    { id: 'record2', name: '스크랩한 기사', Icon: Bookmark }
  ];

  useEffect(() => {
    // Fetch dynamic items if needed
    const fetchDynamicItems = async () => {
      try {
        const response = await fetch('/data/');
        const data = await response.json();
        
        const items = data.map((fileName, index) => ({
          id: `dynamic-${index + 1}`,
          name: fileName.replace('.json', ''),
          Icon: ChevronRight
        }));
        
        setDynamicMenuItems(items);
      } catch (error) {
        console.error('Error fetching menu items:', error);
        setDynamicMenuItems([]);
      }
    };

    fetchDynamicItems();
  }, []);

  // Combine static and dynamic items
  const allItems = [...staticItems, ...dynamicMenuItems];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between px-4">
        <h2 className="text-sm font-semibold text-gray-800">기사 목록</h2>
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-gray-600 hover:bg-gray-100 rounded-full p-1"
          aria-label={isExpanded ? "Collapse article list" : "Expand article list"}
        >
          {isExpanded ? 
            <ChevronDown className="w-5 h-5" /> : 
            <ChevronRight className="w-5 h-5" />
          }
        </button>
      </div>

      {isExpanded && (
        <div className="space-y-1">
          {allItems.map(item => (
            <div
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition-colors ${
                activeSection === item.id
                  ? 'text-[#00c853] bg-[#e8f5e9]'
                  : 'text-gray-600 hover:bg-[#e8f5e9]'
              }`}
              role="button"
              tabIndex={0}
              onKeyPress={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  setActiveSection(item.id);
                }
              }}
            >
              <item.Icon className="w-4 h-4" />
              <div className="text-sm font-medium">{item.name}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

ArticleSelection.propTypes = {
  articleItems: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      Icon: PropTypes.elementType.isRequired
    })
  ),
  activeSection: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  setActiveSection: PropTypes.func.isRequired
};

ArticleSelection.defaultProps = {
  articleItems: []
};

export default ArticleSelection;